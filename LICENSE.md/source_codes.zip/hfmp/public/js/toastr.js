/*
Template Name: Monster Admin
Author: Themedesigner
Email: niravjoshi87@gmail.com
File: js
*/
$(function() {
    "use strict";
      $(".tst1").click(function(){
           $.toast({
            heading: 'Welcome to Monster admin',
            text: 'Use the predefined ones, or specify a custom position object.',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'info',
            hideAfter: 3000, 
            stack: 6
          });

     });


     /* var toastI = 0;
      $(".tst2").click(function(){

           var sendto = $('input#sendto').val().split(";");
           console.log("###### S E N D T O ###########")
           console.log(sendto);
          console.log("current toastI is ", toastI);
          
          function doToast(val,sendto){
            setTimeout(function(val,sendto){
              console.log("current toastI is ", val);
              if(val<sendto.length-1)doToast(toastI++,sendto);
            },3000);            
          }
           


                console.log("current toastI is ", toastI);
                
                setTimeout(function(){
                  $.toast({
                  heading: 'Sending SMS',
                  text: 'HFMP Server is processing an SMS to ' + sendto[toastI++] + ' thru API',
                  position: 'top-right',
                  loaderBg:'#ff6849',
                  icon: 'success',
                  hideAfter: 3500, 
                  stack: 6
                  });                  
                }, 3000);
              
            }

     });*/
      $(".tst3").click(function(){
           $.toast({
            heading: 'Welcome to Monster admin',
            text: 'Use the predefined ones, or specify a custom position object.',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'success',
            hideAfter: 3500, 
            stack: 6
          });

     });

      $(".tst4").click(function(){
           $.toast({
            heading: 'Welcome to Monster admin',
            text: 'Use the predefined ones, or specify a custom position object.',
            position: 'top-right',
            loaderBg:'#ff6849',
            icon: 'error',
            hideAfter: 3500
            
          });

     });
});
          
