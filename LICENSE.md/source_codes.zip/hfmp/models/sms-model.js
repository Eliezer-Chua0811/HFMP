const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const smsSchema = new Schema({
	status: String,
	send_to: String,
	sms: String,	
	api_key: String,	
	processed_by: String,
	date: { type: Date, default: Date.now }
});

const Sms = mongoose.model('sms', smsSchema);

module.exports = Sms;