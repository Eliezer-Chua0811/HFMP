const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const announcementSchema = new Schema({
	username: String,
	googleID: String,
	thumbnail: String,
	content: String,
	ayos: String,	
	userType: String,
	image: String,
	url: String,
	isArticle: String,
	isSeminar: String,
	date: { type: Date, default: Date.now },
	comment: []
});

const Announcement = mongoose.model('announcement', announcementSchema);

module.exports = Announcement;