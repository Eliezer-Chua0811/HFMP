const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
	username: String,
	googleID: String,
	thumbnail: String,
	email: String,
	familyName: String,
	givenName: String,
	hfmpProfile: {
		familyName: String,
		givenName: String,
		phonenumber: String,
		chapter: String,
		userType: String,
		info:{
			middleName: String,
			dateOfBirth: String,
			placeOfBirth: String,
			age: String,
			citizenship: String,
			gender: String,
			civilStatus: String,
			height: String,
			weight: String,
			bloodType: String,
			philHealthNo: String,
			sssNo: String,
			tinNo: String,
			province: String,
			religion: String,
			telNo: String,
			mobileNo: String,
			nameExtension: String,
			emailAddress: String,
			occupation: String,
			membershipNo: String,
			residential_houseNo: String,
			residential_street: String,
			residential_barangay: String,
			residential_municipal: String,
			permanent_houseNo: String,
			permanent_street: String,
			permanent_barangay: String,
			permanent_municipal: String,
			elem_school: String,
			elem_degree: String,
			elem_from: String,
			elem_to: String,
			seco_school: String,
			seco_degree: String,
			seco_from: String,
			seco_to: String,
			voca_school: String,
			voca_degree: String,
			voca_from: String,
			voca_to: String,
			coll_school: String,
			coll_degree: String,
			coll_from: String,
			coll_to: String
        }
	},
	date: { type: Date, default: Date.now },
	isUpdateProfile: Boolean,
    verify:{
        status: Boolean,
        code: String
    }
});

const User = mongoose.model('user', userSchema);

module.exports = User;