const router = require('express').Router();
const User = require('../models/user-model');
const Announcement = require('../models/announcement-model');
const Sms = require('../models/sms-model');
const clockwork = require('clockwork');

const nodemailer = require('nodemailer');
const keys = require('../config/keys');

const authCheck = (req, res, next)=>{
	if(!req.user){
		//if user is not logged in
		res.redirect('/auth/login');
	}else{
        
        if(req.user.verify.status == undefined || !req.user.verify.status){
            res.redirect("/profile/validatefirst"); 
        }
        else{
		  next();            
        }
	}
};

router.get('/',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	let t = '';
	const thumbnailURL = req.user.thumbnail.split("/");
	for(let i=0;i<7;i++)t+=thumbnailURL[i]+'/';
	t += 'photo.jpg?sz=150';

	console.log(req.user);

/*    console.log("####################");
    console.log(req.user.verify.status);
    console.log("####################");

    if(req.user.verify.status == undefined){
        res.redirect("/profile/validatefirst"); 
    }*/

  /*  if(req.user.verify.status != undefined && !req.user.verify.status){
        res.redirect("validatefirst",{layout:false}); 
    }*/

	res.render('profile', {user: req.user, thumbnail150: t});

	// /* ################### UNDER MAINTENANCE ##############*/
	// res.render("page-maintenance", {layout:false});
	// /* ################### UNDER MAINTENANCE ##############*/


});


router.get('/validatefirst', (req, res)=>{
    res.render("validatefirst", {layout:false});  
});


router.get('/profile',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);


	let t = '';
	const thumbnailURL = req.user.thumbnail.split("/");
	for(let i=0;i<7;i++)t+=thumbnailURL[i]+'/';
	t += 'photo.jpg?sz=150';

	console.log(req.user);


	res.render('profile', {user: req.user, thumbnail150: t});
	// /* ################### UNDER MAINTENANCE ##############*/
	// res.render("page-maintenance", {layout:false, user: req.user});
	// /* ################### UNDER MAINTENANCE ##############*/

});

router.get('/view/:id',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	console.log("id: ", req.params.id);

	User.findById(req.params.id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		const foundUser = foundObject;
		let t = '';
		const thumbnailURL = foundUser.thumbnail.split("/");
		for(let i=0;i<7;i++)t+=thumbnailURL[i]+'/';
		t += 'photo.jpg?sz=150';

		console.log("foundUser: ", foundUser);
		

		res.render('viewprofile', {user: foundUser, thumbnail150: t});
		// /* ################### UNDER MAINTENANCE ##############*/
		// res.render("page-maintenance", {layout:false, user: req.user});
		// /* ################### UNDER MAINTENANCE ##############*/
		
	});

});

router.get('/admin/view/:id',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	console.log("id: ", req.params.id);

	User.findById(req.params.id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		const foundUser = foundObject;
		let t = '';
		const thumbnailURL = foundUser.thumbnail.split("/");
		for(let i=0;i<7;i++)t+=thumbnailURL[i]+'/';
		t += 'photo.jpg?sz=150';

		console.log("foundUser: ", foundUser);
		

		res.render('adminviewprofile', {user: foundUser, thumbnail150: t});
		// /* ################### UNDER MAINTENANCE ##############*/
		// res.render("page-maintenance", {layout:false, user: req.user});
		// /* ################### UNDER MAINTENANCE ##############*/
		
	});

});

router.get('/makeadmin/:id',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	console.log("id: ", req.params.id);

	User.findById(req.params.id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		foundObject.hfmpProfile.userType = "Administrator";

		foundObject.save((err, updatedObject)=>{
			if(err){
				console.error(err);
				res.status(500).send();						
			}else{						
				console.log("Updated Profile changed to Administrator!", updatedObject);
				

				res.redirect('/profile/members');
				// /* ################### UNDER MAINTENANCE ##############*/
				// res.render("page-maintenance", {layout:false, user: req.user});
				// /* ################### UNDER MAINTENANCE ##############*/
			}
		});
		
	});

});

router.get('/removemember/:id',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	const id = req.params.id;
	console.log("id: ", req.params.id);

	User.findByIdAndRemove(id, (err, data)=>{
		if(err){
			console.error(err);
			res.status(500).send(err);
		} 
		const response = {
			message : "User has been successfully deleted.",
			id: id
		};


		res.redirect('/profile/members');
		// /* ################### UNDER MAINTENANCE ##############*/
		// res.render("page-maintenance", {layout:false, user: req.user});
		// /* ################### UNDER MAINTENANCE ##############*/
	});


/*	User.findById(req.params.id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		foundObject.hfmpProfile.userType = "Administrator";

		foundObject.save((err, updatedObject)=>{
			if(err){
				console.error(err);
				res.status(500).send();						
			}else{						
				console.log("Updated Profile changed to Administrator!", updatedObject);
				res.redirect('/profile/members');
			}
		});
		
	});*/

});

router.get('/makemember/:id',authCheck, (req, res)=>{
	// res.send('you are logged in. this is your profile - ' + req.user.username);

	console.log("id: ", req.params.id);

	User.findById(req.params.id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		foundObject.hfmpProfile.userType = "Member";

		foundObject.save((err, updatedObject)=>{
			if(err){
				console.error(err);
				res.status(500).send();						
			}else{						
				console.log("Updated Profile changed to Administrator!", updatedObject);
				res.redirect('/profile/members');
			}
		});
		
	});

});

router.post('/',authCheck, (req, res)=>{	
	console.log("Updating profile...");
	console.log(req.body);

	User.findOne({_id: req.body.profile_id},(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();
		}else{
			if(!foundObject){
				res.status(400).send();
			}else{
				if(req.body.profile_familyname){
					foundObject.hfmpProfile.familyName = req.body.profile_familyname;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_givenname){
					foundObject.hfmpProfile.givenName = req.body.profile_givenname;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_phone){
					foundObject.hfmpProfile.phonenumber = req.body.profile_phone;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_chapter){
					foundObject.hfmpProfile.chapter = req.body.profile_chapter;
					foundObject.isUpdateProfile = true;
				}

				/*Additional Profile Info*/

				if(req.body.profile_middleName){
					foundObject.hfmpProfile.info.middleName = req.body.profile_middleName;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_dateOfBirth){
					foundObject.hfmpProfile.info.dateOfBirth = req.body.profile_dateOfBirth;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_placeOfBirth){
					foundObject.hfmpProfile.info.placeOfBirth = req.body.profile_placeOfBirth;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_age){
					foundObject.hfmpProfile.info.age = req.body.profile_age;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_citizenship){
					foundObject.hfmpProfile.info.citizenship = req.body.profile_citizenship;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_gender){
					foundObject.hfmpProfile.info.gender = req.body.profile_gender;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_civilStatus){
					foundObject.hfmpProfile.info.civilStatus = req.body.profile_civilStatus;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_height){
					foundObject.hfmpProfile.info.height = req.body.profile_height;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_weight){
					foundObject.hfmpProfile.info.weight = req.body.profile_weight;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_bloodType){
					foundObject.hfmpProfile.info.bloodType = req.body.profile_bloodType;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_philHealthNo){
					foundObject.hfmpProfile.info.philHealthNo = req.body.profile_philHealthNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_sssNo){
					foundObject.hfmpProfile.info.sssNo = req.body.profile_sssNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_tinNo){
					foundObject.hfmpProfile.info.tinNo = req.body.profile_tinNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_province){
					foundObject.hfmpProfile.info.province = req.body.profile_province;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_religion){
					foundObject.hfmpProfile.info.religion = req.body.profile_religion;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_telNo){
					foundObject.hfmpProfile.info.telNo = req.body.profile_telNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_mobileNo){
					foundObject.hfmpProfile.info.mobileNo = req.body.profile_mobileNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_nameExtension){
					foundObject.hfmpProfile.info.nameExtension = req.body.profile_nameExtension;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_emailAddress){
					foundObject.hfmpProfile.info.emailAddress = req.body.profile_emailAddress;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_occupation){
					foundObject.hfmpProfile.info.occupation = req.body.profile_occupation;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_membershipNo){
					foundObject.hfmpProfile.info.membershipNo = req.body.profile_membershipNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_residential_houseNo){
					foundObject.hfmpProfile.info.residential_houseNo = req.body.profile_residential_houseNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_residential_street){
					foundObject.hfmpProfile.info.residential_street = req.body.profile_residential_street;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_residential_barangay){
					foundObject.hfmpProfile.info.residential_barangay = req.body.profile_residential_barangay;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_residential_municipal){
					foundObject.hfmpProfile.info.residential_municipal = req.body.profile_residential_municipal;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_permanent_houseNo){
					foundObject.hfmpProfile.info.permanent_houseNo = req.body.profile_permanent_houseNo;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_permanent_street){
					foundObject.hfmpProfile.info.permanent_street = req.body.profile_permanent_street;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_permanent_barangay){
					foundObject.hfmpProfile.info.permanent_barangay = req.body.profile_permanent_barangay;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_permanent_municipal){
					foundObject.hfmpProfile.info.permanent_municipal = req.body.profile_permanent_municipal;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_elem_school){
					foundObject.hfmpProfile.info.elem_school = req.body.profile_elem_school;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_elem_degree){
					foundObject.hfmpProfile.info.elem_degree = req.body.profile_elem_degree;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_elem_from){
					foundObject.hfmpProfile.info.elem_from = req.body.profile_elem_from;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_elem_to){
					foundObject.hfmpProfile.info.elem_to = req.body.profile_elem_to;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_seco_school){
					foundObject.hfmpProfile.info.seco_school = req.body.profile_seco_school;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_seco_degree){
					foundObject.hfmpProfile.info.seco_degree = req.body.profile_seco_degree;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_seco_from){
					foundObject.hfmpProfile.info.seco_from = req.body.profile_seco_from;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_seco_to){
					foundObject.hfmpProfile.info.seco_to = req.body.profile_seco_to;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_voca_school){
					foundObject.hfmpProfile.info.voca_school = req.body.profile_voca_school;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_voca_degree){
					foundObject.hfmpProfile.info.voca_degree = req.body.profile_voca_degree;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_voca_from){
					foundObject.hfmpProfile.info.voca_from = req.body.profile_voca_from;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_voca_to){
					foundObject.hfmpProfile.info.voca_to = req.body.profile_voca_to;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_coll_school){
					foundObject.hfmpProfile.info.coll_school = req.body.profile_coll_school;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_coll_degree){
					foundObject.hfmpProfile.info.coll_degree = req.body.profile_coll_degree;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_coll_from){
					foundObject.hfmpProfile.info.coll_from = req.body.profile_coll_from;
					foundObject.isUpdateProfile = true;
				}

				if(req.body.profile_coll_to){
					foundObject.hfmpProfile.info.coll_to = req.body.profile_coll_to;
					foundObject.isUpdateProfile = true;
				}

				foundObject.save((err, updatedObject)=>{
					if(err){
						console.error(err);
						res.status(500).send();						
					}else{						
						console.log("Updated Profile", updatedObject);
						res.redirect('profile');
					}
				});
			}

		}
	});

	// let id = req.params._id;
	// console.log("id: ", id);
});

router.get('/members',authCheck, (req, res)=>{
	const user = new User();
	User.find({},null, {sort: {date: -1}}, (err, foundData)=>{
		let members = {};
		if(err){
			console.error(err);
			res.status(500).send();
		}else{
			members = foundData;
			console.log(foundData);
		}
		res.render('members', {user: req.user, members: members});
	});

});

router.get('/admin',authCheck, (req, res)=>{
	const user = new User();
	User.find({},null, {sort: {date: -1}}, (err, foundData)=>{
		let members = {};
		if(err){
			console.error(err);
			res.status(500).send();
		}else{
			members = foundData;
			//console.log(foundData);
		}
		res.render('admin', {user: req.user, members: members});
	});

});

router.post('/post',authCheck, (req, res)=>{
	console.log("Posting...");
	const user = req.user;
	const content = req.body.announcement;
	const anndata = {
		username: user.username,
		googleID: user.googleID,
		thumbnail: user.thumbnail,
		content: content,
		ayos: 0,	
		userType: user.hfmpProfile.userType,
		image: req.body.imageURL,
		url: req.body.webURL,
		isArticle: req.body.chkboxArticle,
		isSeminar: req.body.chkboxSeminar
		
	};
	const ann = new Announcement(anndata)
	.save((err)=>{
		if(err)console.log(err);

		console.log("saving...");
		const announcement = new Announcement();
		Announcement.find({},null, {sort: {date: -1}}, (err, foundData)=>{
			let posts = {};
			if(err){
				console.error(err);
				res.status(500).send();
			}else{
				posts = foundData;
				console.log(posts);
			}		
			res.render('page-dashboard', {user: req.user, posts: posts});
		});
	})
	.then((newAnnouncement)=>{
		console.log('new announcement created:' + newAnnouncement);
		done(null, newUser);
	});		

	
});

router.get('/deletepost/:id',authCheck, (req, res)=>{
	const id = req.params.id;
	console.log("deleting ", id, " ...");
	Announcement.findByIdAndRemove(id, (err, data)=>{
		if(err){
			console.error(err);
			res.status(500).send(err);
		} 
		const response = {
			message : "Announcement has been successfully deleted.",
			id: id
		};
		res.redirect('/page-dashboard');
	});
});

router.get('/ayos/:id',authCheck,(req,res)=>{
	const id = req.params.id;
	console.log(`${id} ayos by ${req.user._id}`);
	Announcement.findOne({_id: id},(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();
		}else{
			if(!foundObject){
				res.status(400).send();
			}else{

				//foundObject.ayos += "," + req.user._id;

				

				const a = foundObject.ayos.split(",");
				let isFound = false;
				for(let x=0;x<a.length;x++){
					if(a[x] == req.user._id){
						isFound = true;
						break;
					}
				}

				if(!isFound){
					foundObject.ayos += "," + req.user._id;
				}else{
					foundObject.ayos = foundObject.ayos;
				}

				


				foundObject.save((err, updatedObject)=>{
					if(err){
						console.error(err);
						res.status(500).send();						
					}else{						
						console.log("Updated Profile", updatedObject);
						res.redirect('/page-dashboard');
					}
				});
			}

		}
	});
});

router.get('/comment/:id',authCheck,(req,res)=>{
	const comment_id = req.params.id;
	const user_id = req.user._id;
	console.log(`commenting ${comment_id} by ${user_id}`);

	Announcement.findOne({_id: comment_id},(err, foundObject)=>{
		if(err){console.error(err); res.status(500).send(); }
		else{
			if(!foundObject){res.status(400).send(); }
			else{

				User.findOne({_id: user_id},(err,userObject)=>{
					if(err){console.error(err); res.status(500).send(); }
					else{
						if(!userObject){res.status(400).send(); }
						res.render('page-comment', {user: req.user, post: foundObject, userCompleteDetails: userObject});
					}
				});
			}

		}
	});
	
});


router.post('/comment/savecomment',authCheck,(req,res)=>{
	console.log("##############################");
	console.log("S A V I N G   C O M M E N T");
	console.log("##############################");
	console.log(req.body);
	const comment_id = req.body.txtPostID;
	Announcement.findOne({_id: comment_id},(err, foundObject)=>{
		if(err){console.error(err); res.status(500).send(); }
		else{
			if(!foundObject){res.status(400).send(); }
			else{

				console.log("found Object");

				const comment = {
					user_id: req.body.txtUserID,
					user_thumbnail: req.body.txtUserThumbnail,
					user_email: req.body.txtUserEmail,
					user_username: req.body.txtUsername,
					user_comment: req.body.txtComment,
				};

				foundObject.comment.push(comment);

				foundObject.save((err, updatedObject)=>{
					if(err){
						console.error(err);
						res.status(500).send();						
					}else{						
						console.log("Updated Profile", updatedObject);
						res.redirect('/page-dashboard');
					}
				});

			}

		}
	});	
});

router.post('/api/sendsms',(req,res)=>{
	console.log('posting - ', req.body);
	const footer = `-HFMP`;
	const apikey = req.body.apikey;
	const sendto = req.body.sendto;
	const content = req.body.sms.substring(0,20);
	const send = sendto.split(";");	
	// res.sendStatus(200);
	res.setHeader('Content-Type', 'application/json');

	let result = [];

	Promise.all(
		send.map(number=>{
			return clockwork({key:apikey}).sendSms({ To: number, Content: content + footer},(err,resp)=>{
				if(err)console.log ('error', err.message, err.stack)
				return resp;
			});	
		})
	)
	.then(message => {
		res.send(JSON.stringify({result:'success', msg: message, sendto: send}));	
	})
	.catch(err => {
		res.send(JSON.stringify({result:'error', msg: err, sendto: send}));
	});

	
});

router.post('/sendsms',authCheck,(req,res)=>{
	console.log("##############################");
	console.log("S E N D I N G  S M S using Clockworks");
	console.log("##############################");	
	console.log(req.body);

	const footer = `-HFMP`;
	const apikey = req.body.apikey;
	const sendto = req.body.sendto;
	const content = req.body.sms.substring(0,20);

	const send = sendto.split(";");

	res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify({ a: 1, sendto: send }, null, 3));

/*	function doSend(msg,callback1){
		clockwork({key:apikey}).sendSms({ To: msg, Content: content + footer}, 
		  function(error, resp) {
		    if (error) {
		        // console.log('Something went wrong', error);
		        console.log("doSend error");
		        return callback1(error);
		    } 		    
		    else {
		    	console.log("doSend success");
		        // console.log('Message sent',resp.responses[0].id);						        
		    }
		    
		});	
	}

	function massSend(callback2){
		send.map((msg)=>{
			doSend(msg,function(err){
				if(err) 
				{x
						return callback2(err);
						console.log(">>>>>>>>>> E R R O R! <<<<<<<<<<<");
				}
				// else console.log(">>>>>>>>>>> S U C C E S S! <<<<<<<<<<<<");
			});
		});
	}

	massSend(function(err){
		if(err){
			res.render('page-smsresult', {user: req.user, result: "SMS Sent successfully. One (1) text has been deducted to the sms api key."});
			next();
		}else{
			res.render('page-smsresult', {user: req.user, result: err.errDesc});
			next();
		}
	});*/



/*	let result = true;
	let err = "";
	let i=0;*/
	/*while(i<send.length){
		if(send[i].length>=10 && send[i].length<=13){	
			if(send[i].charAt(0)=='0' || send[i].charAt(0)=='+' || send[i].charAt(0)=='9'){
							


				doCall(function(response){
					if(!response)result = false;
					console.log("sending sms to: ",send[i], " ===> ", result);	
					i++;
				});


			}		
		}
	}

	function doCall(callback){
		var clockwork = require('clockwork')({key:apikey});
		clockwork.sendSms({ To: send[i], Content: content + footer}, 
		  function(error, resp) {
		    if (error) {
		        console.log('Something went wrong', error);
		        err = error;	
		        return callback(false);
		    } else {
		        console.log('Message sent',resp.responses[0].id);						        
		        return callback(true);
		    }
		});			
	}*/

/*


	function doCall(callback){
		var clockwork = require('clockwork')({key:apikey});
		send.map((msg)=>{
			if(msg.length>=10 && msg.length<=13){	
				if(msg.charAt(0)=='0' || msg.charAt(0)=='+' || msg.charAt(0)=='9'){
					clockwork.sendSms({ To: msg, Content: content + footer}, 
					  function(error, resp) {
					    if (error) {
					        console.log('Something went wrong', error);				        
					        err = error;
					        console.log("sending sms to: ",msg, " ===> ", false);	
					        return callback(false);
					    } else {
					        console.log('Message sent',resp.responses[0].id);
					        console.log("sending sms to: ",msg, " ===> ", true);
					    }

					});					
				}
			}
		});	
		return callback(true);	
	}

	doCall(function(response){
		console.log(">>>>>>>>>>", response);
		if(!response)return callback(false);
	
		if(response){
			res.render('page-smsresult', {user: req.user, result: "SMS Sent successfully. One (1) text has been deducted to the sms api key."});
		}else{
			res.render('page-smsresult', {user: req.user, result: err.errDesc});
		}
	},callback);
*/
});

router.post('/sendsms2',authCheck,(req,res)=>{
	console.log("##############################");
	console.log("S E N D I N G  S M S using ItextMo");
	console.log("##############################");	
	console.log(req.body);

	const footer = `--by HFMP dnt reply!`;
	const to = req.body.sendto;
	const content = req.body.sms.substring(0,139) + footer


	const axios = require('axios');
	axios.post('https://www.itexmo.com/php_api/api.php', {
		"1":to,
		"2":content, 
		"3":"TR-AMADE258630_FEJQE",
		"5":"HIGH"
	})
	.then(function (response) {
		console.log(response.statusText);
	})
	.catch(function (error) {
		console.log(error);
	});
});

router.post('/categorization',authCheck,(req, res)=>{
	console.log("##############################");
	console.log("C A T E G O R I Z A T I O N");
	console.log("##############################");	
	console.log(req.body);	

	/*
		Portrait
		8.5 x 11
		9 Fields
	*/

	User.find({},null, {sort: {date: -1}}, (err, foundData)=>{
		let users = {};
		if(err){
			console.error(err);
			res.status(500).send();
		}else{
			users = foundData;
			console.log(users);

			var xl = require('excel4node');
			var wb = new xl.Workbook();
			 
			// Add Worksheets to the workbook 
			var ws = wb.addWorksheet('Sheet 1');
			var ws2 = wb.addWorksheet('Sheet 2');
			 
			// Create a reusable style 
			var style = wb.createStyle({
			    font: {
			        color: '#FF0800',
			        size: 12,
			        bold:true
			    },
				alignment: {
					wrapText : true
				},
			    numberFormat: '$#,##0.00; ($#,##0.00); -',
			    border: {left:{style:"thick"}, right:{style:"thick"}, top:{style:"thick"}, bottom:{style:"thick"} }
			});

			var style2 = wb.createStyle({
			    font: {
			        size: 12
			    },
				alignment: {
					wrapText : true
				},
			    border: {left:{style:"thin"}, right:{style:"thin"}, top:{style:"thin"}, bottom:{style:"thin"} }
			});

			var style3 = wb.createStyle({ 
				font: { size:10 },
				alignment: {
					wrapText : true
				},
			    border: {left:{style:"thin"}, right:{style:"thin"}, top:{style:"thin"}, bottom:{style:"thin"} }
			});
			 

			ws.cell(9, 1, 9, 8, true).string('CATEGORIZED LIST OF HFMP MEMBERS').style({font:{bold:true,underline:true,size:18},alignment:{horizontal: 'center'}});

			let row = 11;

			ws.cell(row,1).string('Surname').style(style);
			ws.cell(row,2).string('Firstname').style(style);
			ws.cell(row,3).string('Region').style(style);
			ws.cell(row,4).string('Province').style(style);
			ws.cell(row,5).string('Email Address').style(style);
			ws.cell(row,6).string('Mobile No.').style(style);
			ws.cell(row,7).string(' ').style(style);
			ws.cell(row,8).string(' ').style(style);
			ws.cell(row,9).string(' ').style(style);


			console.log("######################################");
			console.log("C A T E G O R I Z A T I O N  U S E R S");
			console.log("######################################");				
			for(let i=0;i<users.length;i++){
				row++;
				console.log(`##################  ROW:${row},i:${i} ################`);
				//console.log(users[i].hfmpProfile.phonenumber);
				const familyName = users[i].familyName;
				if(familyName != undefined){					
					ws.cell(row,1).string(familyName).style(style2);
				}else{
					ws.cell(row,1).string(' - ').style(style2);
				}
				const givenName = users[i].givenName;
				if(givenName != undefined){					
					ws.cell(row,2).string(givenName).style(style2);
				}else{
					ws.cell(row,2).string(' - ').style(style2);
				}
				const chapter = users[i].hfmpProfile.chapter;
				if(chapter != undefined){					
					ws.cell(row,3).string(chapter).style(style2);
				}else{
					ws.cell(row,3).string(' - ').style(style2);
				}
				const province = users[i].hfmpProfile.info.province;
				if(province != undefined){					
					ws.cell(row,4).string(province).style(style2);
				}else{
					ws.cell(row,4).string(' - ').style(style2);
				}
				const email = users[i].email;
				if(email != undefined){					
					ws.cell(row,5).string(email).style(style2);
				}else{
					ws.cell(row,5).string(' - ').style(style2);
				}
				const phonenumber = users[i].hfmpProfile.phonenumber;
				if(phonenumber != undefined){					
					ws.cell(row,6).string(phonenumber).style(style2);
				}else{
					ws.cell(row,6).string(' - ').style(style2);
				}						
				ws.cell(row,7).string(' ').style(style2);
				ws.cell(row,8).string(' ').style(style2);
				ws.cell(row,9).string(' ').style(style2);
			}



			/*row++;
			ws.cell(row,1).string('Hfmp').style(style2);
			ws.cell(row,2).string('Member').style(style2);
			ws.cell(row,3).string('Region XI').style(style2);
			ws.cell(row,4).string('Davao').style(style2);
			ws.cell(row,5).string('hfmpmember@gmail.com').style(style2);
			ws.cell(row,6).string('0987234232').style(style3);
			ws.cell(row,7).string(' ').style(style2);
			ws.cell(row,8).string(' ').style(style2);
			ws.cell(row,9).string(' ').style(style2);*/

			row+=2;
			ws.cell(row,1).string(`Date Printed: `).style({font:{size:10}});
			ws.cell(row,2).date(new Date()).style({ 
				numberFormat: 'yyyy-mm-dd',		
				font:{
					size:10
				}
			});

			ws.cell(row,8).string(`Total Rows: `).style({font:{size:10}});
			ws.cell(row,9).string(users.length+"").style({font:{size:10, bold:true}});

			row+=2;
			ws.cell(row,1).string('This form is generated by HFMP website (c) 2018. A capstone of Mr. Tizon and Chua in AMA Computer College Davao Campus.').style({font:{size:10}});


			ws.addImage({
			    path: './public/img/logo.jpg',
			    type: 'picture',
			    position: {
			        type: 'twoCellAnchor',
			        from: {
			            col: 1,
			            colOff: 0,
			            row: 1,
			            rowOff: 0
			        },
			        to: {
			            col: 10,
			            colOff: 0,
			            row: 8,
			            rowOff: 0
			        }
			    }
			});
			 
			wb.write('categorization.xlsx', res);	



		}				
	});




	//res.render('categorization',{ user:req.user });
});


router.post('/sms/mass',authCheck,(req, res)=>{
	console.log("######################################");
	console.log("S M S  M A S S  N O T I F I C A T I O N");
	console.log("######################################");	

	console.log(req.body);

	if(req.body.sendto!=undefined){		
		let sendto = req.body.sendto.split(';');
		let sms = req.body.sms;
		let apikey = req.body.apikey;

		let smsData = [];
		for(let i=0;i<sendto.length-1;i++){
			let obj = {
				status: "SENDING",
				send_to: sendto[i],
				sms: sms,
				api_key: apikey,
				processed_by: req.user.username
			};
			smsData.push(obj);
		}

		Sms.insertMany(smsData,(err)=>{
			if(err){
				console.error(err);			
				res.status(500).send();
			}
			else{
				res.render('sms', {user: req.user, data: req.body});
			}
		});
	}else{
		res.render('sms', {user: req.user, data: req.body});		
	}
});

router.get('/sms/log/sending',authCheck,(req, res )=>{
	console.log("######################################");
	console.log("S M S  L O G  S E N D I N G");
	console.log("######################################");	

	res.setHeader('Content-Type', 'application/json');
	Sms.find({status: "SENDING"},null, {sort: {date: -1}}, (err, foundData)=>{
		let sms = {};
		if(err){
			console.error(err);
			
			//res.status(500).send();
			res.send(JSON.stringify({result:'error', data: err}));
		}else{
			sms = foundData;
			console.log(sms);

			res.send(JSON.stringify({result:'success', data: sms}));
		}
	});
});

router.get('/sms/log/data',authCheck,(req, res )=>{
	console.log("######################################");
	console.log("S M S  L O G  D A T A");
	console.log("######################################");	


	res.setHeader('Content-Type', 'application/json');
	Sms.find({status: { $in : ["SENT SUCCESSFULLY", "SENDING FAILED"]}},null, {sort: {date: -1}}, (err, foundData)=>{
		let sms = {};
		if(err){
			console.error(err);
			
			//res.status(500).send();
			res.send(JSON.stringify({result:'error', data: err}));
		}else{
			sms = foundData;
			console.log(sms);

			res.send(JSON.stringify({result:'success', data: sms}));
		}
	});
});

router.get('/sms/log',authCheck,(req, res )=>{
	console.log("######################################");
	console.log("S M S  L O G");
	console.log("######################################");	

	Sms.find({status: { $in : ["SENT SUCCESSFULLY", "SENDING FAILED"]}},null, {sort: {date: -1}}, (err, foundData)=>{
		let sms = {};
		if(err){
			console.error(err);
			
			res.status(500).send();
			//res.send(JSON.stringify({result:'error', data: err}));
		}else{
			sms = foundData;
			console.log(sms);

			// res.send(JSON.stringify({result:'success', data: sms}));
			res.render('sms-logs', {user: req.user, smsData: sms});
		}
	});
	
});

router.get('/api/sms/send',(req,res)=>{
	res.setHeader('Content-Type', 'application/json');	
	Sms.findOne({status: "SENDING"}, null, { sort: {date: -1}}, function(err, foundData) {
	  if(err){
	  	res.send(JSON.stringify({result:'error', sendData: err}));
	  }
	  else{
	  	//console.log( post );
	  	let send = foundData;
	  	res.send(JSON.stringify({result:'success', sendData: send}));
	  }
	});
});

router.post('/api/sms/send',(req,res)=>{
	console.log("######################################");
	console.log("S M S  S E N D I N G  T H R U  C L O C K W O R K  A P I");
	console.log("######################################");		
	console.log('posting - ', req.body);
	const footer = `-HFMP`;
	const apikey = req.body.apikey;
	const sendto = req.body.sendto;
	const content = req.body.content.substring(0,20) + footer;

	res.setHeader('Content-Type', 'application/json');

	clockwork({key: apikey}).sendSms({To: sendto, Content: content},
		function(err,resp){
			// console.log("######################################");
			// console.log("R E S U L T : C L O C K W O R K  A P I");
			// console.log("######################################");				
			if(err){
				// console.log ('error: ', err.message, err.stack);

				res.send(JSON.stringify({result:'error', msg: err.message, data: req.body}));
			}
			else{
				// console.log ('success: ',resp);
				res.send(JSON.stringify({result:'success', msg: resp, data: req.body}));
			}					
	});	


/*	clockwork({key:apikey}).sendSms({ To: msg, Content: content + footer}, 
		function(error, resp) {
		if (error) {
			// console.log('Something went wrong', error);
			console.log("doSend error");
			return callback1(error);
		} 		    
		else {
			console.log("doSend success");
			// console.log('Message sent',resp.responses[0].id);						        
		}

	});	*/	
	
});

router.put('/api/sms/send',(req,res)=>{
	console.log("######################################");
	console.log("S M S  U P D A T E");
	console.log("######################################");		
	console.log('updating - ', req.body);
	const id = req.body._id;
	const status = req.body.status;

	Sms.findById(id,(err, foundObject)=>{
		if(err){
			console.error(err);
			res.status(500).send();			
		}

		foundObject.status = status;

		foundObject.save((err, updatedObject)=>{
			if(err){
				console.error(err);
				res.status(500).send();						
			}else{						
				console.log("Updated SMS Status!", updatedObject);
				//res.redirect('/profile/members');
				res.end();
			}
		});
		
	});	
});

router.get('/verify/:id',(req,res)=>{
    const id = req.params.id;
    console.log(`>>>>>>> ${id}`);
    User.findOne({_id: id},(err,foundObject)=>{
        if(err){
            console.error(err);
            res.status(500).send();
        }else{
            if(!foundObject){
                res.status(400).send();
            }else{

                if(foundObject.verify.status!=undefined && !foundObject.verify.status && foundObject.verify.code.length>0){

                    res.render('verifycode', {user: req.user, member: foundObject, status: 'already sent', info: 'already sent'});

                }else{

                    const email = foundObject.email;
                    console.log(`Email: ${email}`);

                    /*CODE GENERATION*/                
                    let code = makeCode();

                    /*UPDATE PROFILE AND SAVE GENERATED CODE*/
                    foundObject.verify.status = false;
                    foundObject.verify.code = code;

                    foundObject.save((err, updatedObject)=>{
                        if(err){
                            console.error(err);
                            res.status(500).send();                     
                        }else{                      
                            /*E M A I L  C O N T E N T*/
                            const completeName = foundObject.hfmpProfile.givenName + " " + foundObject.hfmpProfile.familyName;
                            const content = getContent(completeName, code, foundObject);            

                            /*S E N D  E M A I L*/
                            let transporter = nodemailer.createTransport({
                                service: 'gmail',
                                auth:{
                                    user: keys.nodemailer.user,
                                    pass: keys.nodemailer.pass
                                }
                            });

                            let mailOptions = {
                                from: `"HFMP Admin" <${keys.nodemailer.user}>`,
                                to: email,
                                subject: 'HFMP Account Verification',
                                html: content
                            };

                            transporter.sendMail(mailOptions, (error, info)=>{
                                if(error) {
                                    console.log(error);                                
                                    // res.redirect('/profile/admin');
                                    res.render('verifycode', {user: req.user, member: foundObject, status: 'sending failed', info: JSON.stringify(error)});
                                }
                                else {
                                    console.log(info);     
                                    console.log("Updated Code Verification Data!", updatedObject.verify);                                
                                    // res.redirect('/profile/admin');
                                    res.render('verifycode', {user: req.user, member: foundObject, status: 'sent successfully', info: JSON.stringify(info)});
                                }                             
                            });

                        }
                    });
                }

                /*console.log(content);
                res.send(content);*/

            }
        }
    });
});

router.get('/verifynew/:id',(req,res)=>{
    const id = req.params.id;
    User.findOne({_id: id},(err,foundObject)=>{
        if(err){
            console.error(err);
            res.status(500).send();
        }else{
            if(!foundObject){
                res.status(400).send();
            }else{

                const email = foundObject.email;
                console.log(`Email: ${email}`);

                /*CODE GENERATION*/                
                let code = makeCode();

                /*UPDATE PROFILE AND SAVE GENERATED CODE*/
                foundObject.verify.status = false;
                foundObject.verify.code = code;

                foundObject.save((err, updatedObject)=>{
                    if(err){
                        console.error(err);
                        res.status(500).send();                     
                    }else{                      
                        /*E M A I L  C O N T E N T*/
                        const completeName = foundObject.hfmpProfile.givenName + " " + foundObject.hfmpProfile.familyName;
                        const content = getContent(completeName, code, foundObject);            

                        /*S E N D  E M A I L*/
                        let transporter = nodemailer.createTransport({
                            service: 'gmail',
                            auth:{
                                user: keys.nodemailer.user,
                                pass: keys.nodemailer.pass
                            }
                        });

                        let mailOptions = {
                            from: `"HFMP Admin" <${keys.nodemailer.user}>`,
                            to: email,
                            subject: 'HFMP Account Verification',
                            html: content
                        };

                        transporter.sendMail(mailOptions, (error, info)=>{
                            if(error) {
                                console.log(error);                                
                                // res.redirect('/profile/admin');
                                res.render('verifycode', {user: req.user, member: foundObject, status: 'sending failed'});
                            }
                            else {
                                console.log(info);     
                                console.log("Updated Code Verification Data!", updatedObject.verify);                                
                                // res.redirect('/profile/admin');
                                res.render('verifycode', {user: req.user, member: foundObject, status: 'sent successfully'});
                            }                             
                        });

                    }
                });
           


            }
        }
    });
});

const makeCode = ()=>{var text = ""; var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"; for (var i = 0; i < 5; i++) text += possible.charAt(Math.floor(Math.random() * possible.length)); return text; }
const getContent = (completeName, code, foundObject)=>{return ` <!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <title>Document</title> <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine"> <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto"> <style> body{color: white; font-family: 'Roboto', serif; margin: 0; } div#head {font-family: 'Tangerine', serif; font-size: 48px; text-shadow: 4px 4px 4px #aaa; } div#content{margin: 20px 25% 20px 25%; } div#all{background-image: url("http://d8st7idcnjoas.cloudfront.net/galfull/CT-829.jpg"); background-size: cover; color: #fff; } </style> </head> <body> <div id="all"> <center> <div> <img src="http://project-hfmp.herokuapp.com/public/img/logo.jpg" alt="hfmp" width="100%" height="200px"> </div> <div id="head">Account Verification</div> </center> <div id="content"> <div> Hello <em style="color:#0f0c29;">${getName(completeName,foundObject.username)}</em>, <br/> <br/> We are pleased to inform you that Hugpong Federal Movement of the Philippines (HFMP) welcomes you to the site. <br/> <br/> This is to inform you that your account need to be verified. </div> <br/> <br/> <center> <b style="font-size: 2rem;">CODE</b> <br/> <span style="font-size: 4rem;color:#0f0c29;">${code}</span> </center> <br/> <br/> Verify your code <a target="_blank"
href="http://project-hfmp.herokuapp.com/validatecode?ref=${foundObject._id}.${code}" style="color:red">here</a> or copy and paste the following URL to a new tab:
http://project-hfmp.herokuapp.com/validatecode?ref=${foundObject._id}.${code} 
<br/> <br/> <div> Keep supporting our dear President Rodrigo Roa Duterte. <br/> <br/> Thank you and more power! </div> <br/> <br/> <center> <span style="font-size: 0.6rem;">Copyright (c) 2018</span><br/> <span style="font-size: 0.8rem;">Hugpong Federal Movement of the Philippines</span><br/> <span style="font-size: 0.6rem;">This output is an IT Capstone of AMA Computer College Davao Campus</span><br/> <span style="font-size: 0.6rem;">Davao City, Philippines (8000)</span><br/> </center> <br/> <br/> </div> </div> </body> </html> `; }
const getName = (name1, name2)=>{if(name1.length>1){return name1; } return name2; }

module.exports = router;